
#----------------------------------------------------------------------
# SURFRIG LICENSE AGREEMENT
# By using any part of SurfRig or bkTools (the contents of this repository),
# you agree to the terms of this license.
# 
# SurfRig & bkTools (the "software") is the property of Brendan Kelly and, therefore,
# is protected by international copyright law. And international copyright
# ASSASSINS, probably.
#
# The software shall be licensed ONLY to individual humans, not to any
# non-human entities, such as corporations, birds, or Mars rovers.
# The software is provided to you, the human licensee, for whatever purposes,
# commercial or otherwise, you wish to use it for - excluding ILLEGAL activity.
# Seriously, don't blow people up with it.
# Blowing up 3D models of people in Maya is fine and, indeed, encouraged.
#
# You may not, under any circumstances, remove or in any way alter 
# this license agreement.
#
# You are prohibited from re-distributing copies of the software to others.
# Just tell them to be nice and get their own. It's free.
# You may use the software on an unlimited number of YOUR OWN machines.
#
# You are prohibited from removing any copyrights or credits
# from the software. You are free to edit the software FOR YOUR OWN PURPOSES,
# but you must explicitly take credit for ANYTHING which is changed, and you
# are prohibited from distributing your edited version of the software.
#
# The software is provided "AS IS", without any warranty for its past,
# current or future functionality. Under no circumstances shall the 
# author of the software be held liable for any claims or damages 
# arising from the use of or other activities involving the software.
#----------------------------------------------------------------------
